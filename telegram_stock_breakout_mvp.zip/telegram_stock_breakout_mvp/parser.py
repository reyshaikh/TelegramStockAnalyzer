import re
from html import unescape

def clean_message(text):
    text = unescape(text or '')
    text = re.sub(r'<br\s*/?>', '\n', text, flags=re.I)
    text = re.sub(r'<[^>]+>', ' ', text).replace('–','-').replace('—','-')
    return '\n'.join(x.strip() for x in text.splitlines() if x.strip())

def nums(s):
    return [float(x.replace(',','')) for x in re.findall(r'\d[\d,]*(?:\.\d+)?', s)]

def parse_signal(text):
    clean = clean_message(text); lines = clean.splitlines(); upper = clean.upper()
    ignored = ('POSITIONAL','INTRADAY','TRADE','LOOKS','ABOVE','SL','TARGET','HOLD','PLEASE','ALL RESEARCH','STOCK IS')
    symbol = None
    for line in lines:
        c = re.sub(r'[^A-Z0-9&-]', '', line.upper())
        if 2 <= len(c) <= 20 and not any(k in line.upper() for k in ignored) and not c.isdigit():
            symbol = c; break
    bm = re.search(r'(?:ABOVE|BREAKOUT(?:\s+ABOVE)?)\s*[:\-]?\s*([\d,.]+)(?:\s*-\s*([\d,.]+))?', upper)
    sm = re.search(r'(?:\bSL\b|STOP\s*LOSS)\s*[:\-]?\s*([\d,.]+)', upper)
    tm = re.search(r'TARGETS?\s*[:\-]?\s*([\d,.\s-]+)', upper)
    hm = re.search(r'HOLD\s+([^\n]+)', upper)
    b = nums(bm.group(0)) if bm else []
    out = {'strategy':'POSITIONAL' if 'POSITIONAL' in upper else 'UNSPECIFIED','symbol':symbol,'direction':'LONG',
           'breakout_low':b[0] if b else None,'breakout_high':b[1] if len(b)>1 else (b[0] if b else None),
           'stop_loss':float(sm.group(1).replace(',','')) if sm else None,'targets':nums(tm.group(1)) if tm else [],
           'holding_period':hm.group(1).title() if hm else None,'original_clean_text':clean}
    out['missing_fields']=[k for k in ('symbol','breakout_high','stop_loss','targets') if not out.get(k)]
    out['valid']=not out['missing_fields']; return out
