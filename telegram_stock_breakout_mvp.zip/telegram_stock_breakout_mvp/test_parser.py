from parser import parse_signal
s='POSITIONAL TRADE<br><br>SYMBIOTEC<br>Looks Good ABOVE 1182-1185<br><br>SL 1080<br><br>Targets 1225-1250-1275-1300-1350<br><br>Hold few weeks'
x=parse_signal(s); assert x['symbol']=='SYMBIOTEC' and x['breakout_high']==1185 and x['targets']==[1225,1250,1275,1300,1350],x
print(x)
