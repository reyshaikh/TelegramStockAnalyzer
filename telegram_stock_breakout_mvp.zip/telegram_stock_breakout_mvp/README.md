# Telegram Stock Breakout Research MVP

Free local prototype: parse a Telegram positional call, fetch daily personal-use market data, calculate EMA/RSI/ATR/volume/risk-reward, return VALID_SETUP_FOR_REVIEW, WAIT_FOR_CONFIRMATION, REJECT_SETUP, or NO_DECISION, and store an audit log.

## Windows setup
1. Extract and open the folder in VS Code.
2. `python -m venv .venv`
3. `.venv\Scripts\activate`
4. `python -m pip install -r requirements.txt`
5. Copy `.env.example` to `.env`; set the BotFather token.
6. `python test_parser.py`
7. `python bot.py`
8. Paste the sample into your bot.

## Limits
This is educational decision support, not automatic trading or investment advice. yfinance is unofficial and personal-use only; data may be delayed/incomplete. Verify prices, liquidity, announcements and risks with an authorized source. No news, fundamentals, broker execution, fees, taxes, slippage or portfolio exposure are included yet.
