import math, numpy as np, pandas as pd, yfinance as yf

def rsi(s,n=14):
    d=s.diff(); g=d.clip(lower=0).rolling(n).mean(); l=(-d.clip(upper=0)).rolling(n).mean()
    return 100-(100/(1+g/l.replace(0,np.nan)))

def analyze_signal(sig,suffix='.NS'):
    ticker=sig['symbol'] if sig['symbol'].endswith(('.NS','.BO')) else sig['symbol']+suffix
    df=yf.download(ticker,period='6mo',interval='1d',auto_adjust=False,progress=False)
    if df.empty or len(df)<55: raise ValueError(f'Insufficient market data for {ticker}; verify symbol/provider')
    if isinstance(df.columns,pd.MultiIndex): df.columns=df.columns.get_level_values(0)
    df=df.dropna(subset=['Close','High','Low','Volume']).copy(); c=df.Close.astype(float); v=df.Volume.astype(float)
    df['EMA20']=c.ewm(span=20,adjust=False).mean(); df['EMA50']=c.ewm(span=50,adjust=False).mean(); df['RSI14']=rsi(c)
    pc=c.shift(1); tr=pd.concat([(df.High-df.Low).abs(),(df.High-pc).abs(),(df.Low-pc).abs()],axis=1).max(axis=1)
    df['ATR14']=tr.rolling(14).mean(); df['VOL20']=v.rolling(20).mean(); row=df.iloc[-1]
    latest=float(row.Close); breakout=float(sig['breakout_high']); sl=float(sig['stop_loss'])
    vr=float(row.Volume/row.VOL20) if row.VOL20 and not math.isnan(row.VOL20) else None
    rv=float(row.RSI14) if not math.isnan(row.RSI14) else None; e20=float(row.EMA20); e50=float(row.EMA50)
    score=0; good=[]; bad=[]
    if latest>breakout: score+=25; good.append('Latest daily close is above the stated breakout level.')
    else: bad.append('Latest daily close is not above the stated breakout level.')
    if vr is not None and vr>=1.5: score+=20; good.append('Latest volume is at least 1.5x its 20-session average.')
    else: bad.append('Volume confirmation is below 1.5x the 20-session average.')
    if latest>e20>e50: score+=20; good.append('Price and EMA alignment support the daily uptrend.')
    else: bad.append('Daily EMA alignment does not fully support the uptrend.')
    if rv is not None and 50<=rv<=75: score+=15; good.append('RSI is in the configured constructive range.')
    else: bad.append('RSI is outside the configured constructive range.')
    risk=breakout-sl; rr={}
    if risk<=0: bad.append('Invalid stop for a long setup.')
    else:
        rr={str(t):round((float(t)-breakout)/risk,2) for t in sig['targets']}
        if rr and max(rr.values())>=2: score+=20; good.append('At least one target is 2R or better.')
        else: bad.append('No target is 2R or better from the breakout entry.')
    decision='NO_DECISION' if risk<=0 else ('WAIT_FOR_CONFIRMATION' if latest<=breakout else ('VALID_SETUP_FOR_REVIEW' if score>=80 else ('WAIT_FOR_CONFIRMATION' if score>=60 else 'REJECT_SETUP')))
    return {'symbol':ticker,'data_timestamp':str(df.index[-1]),'latest_close':round(latest,2),'breakout_high':breakout,'stop_loss':sl,
            'targets':sig['targets'],'decision':decision,'score':score,'reasons_for':good,'reasons_against':bad,
            'metrics':{'ema20':round(e20,2),'ema50':round(e50,2),'rsi14':round(rv,2) if rv is not None else None,
                       'volume_ratio_20d':round(vr,2) if vr is not None else None,'atr14_pct':round(float(row.ATR14/latest*100),2)},'risk_reward':rr}
