import json, logging, os
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters
from parser import parse_signal
from analyzer import analyze_signal
load_dotenv(); logging.basicConfig(level=logging.INFO)
TOKEN=os.getenv('TELEGRAM_BOT_TOKEN'); ALLOWED=os.getenv('ALLOWED_CHAT_ID','').strip(); SUFFIX=os.getenv('DEFAULT_EXCHANGE_SUFFIX','.NS')

def report(p,r):
    pos='\n'.join('• '+x for x in r['reasons_for']) or '• None'; neg='\n'.join('• '+x for x in r['reasons_against']) or '• None'
    rr=', '.join(f'{k}: {v}R' for k,v in r['risk_reward'].items()) or 'Unavailable'; m=r['metrics']
    return (f"BREAKOUT RESEARCH REPORT\n\nSymbol: {r['symbol']}\nDecision: {r['decision']}\nRules score: {r['score']}/100\n"
            f"Data timestamp: {r['data_timestamp']}\nLatest daily close: {r['latest_close']}\nBreakout: {r['breakout_high']}\nStop: {r['stop_loss']}\n"
            f"Targets: {', '.join(map(str,r['targets']))}\n\nSupporting evidence\n{pos}\n\nRisks / missing confirmation\n{neg}\n\n"
            f"EMA20: {m['ema20']} | EMA50: {m['ema50']} | RSI14: {m['rsi14']}\nVolume ratio: {m['volume_ratio_20d']} | ATR%: {m['atr14_pct']}\n"
            f"Reward-to-risk: {rr}\n\nEducational research support only. Free personal-use data may be delayed or incomplete. Verify with an authorized source and qualified adviser.")
async def start(u:Update,c:ContextTypes.DEFAULT_TYPE): await u.message.reply_text('Paste a positional breakout message for daily-chart validation.')
async def handle(u:Update,c:ContextTypes.DEFAULT_TYPE):
    if ALLOWED and str(u.effective_chat.id)!=ALLOWED: await u.message.reply_text('Chat not authorized.'); return
    try:
        p=parse_signal(u.message.text or '')
        if not p['valid']: await u.message.reply_text('Missing: '+', '.join(p['missing_fields'])); return
        r=analyze_signal(p,SUFFIX); os.makedirs('logs',exist_ok=True)
        with open('logs/audit.jsonl','a',encoding='utf-8') as f: f.write(json.dumps({'input':p,'output':r},default=str)+'\n')
        await u.message.reply_text(report(p,r))
    except Exception as e: logging.exception('failed'); await u.message.reply_text(f'NO_DECISION: {e}')
if __name__=='__main__':
    if not TOKEN: raise RuntimeError('Set TELEGRAM_BOT_TOKEN in .env')
    a=Application.builder().token(TOKEN).build(); a.add_handler(CommandHandler('start',start)); a.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,handle)); a.run_polling()
